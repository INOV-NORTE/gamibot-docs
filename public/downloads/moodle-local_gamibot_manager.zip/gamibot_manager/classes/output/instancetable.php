<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_gamibot_manager\output;

use html_writer;
use local_gamibot_manager\base_instance;
use local_gamibot_manager\local\config_manager;
use local_gamibot_manager\local\tenant;
use local_gamibot_manager\local\userinfo;
use moodle_url;
use renderable;
use renderer_base;
use stdClass;
use templatable;

/**
 * Instance table widget shown on the tenant_config.php page.
 *
 * @package    local_gamibot_manager
 * @copyright  2024 ISB Bayern
 * @author     Philipp Memmel
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class instancetable implements renderable, templatable {

    #[\Override]
    public function export_for_template(renderer_base $output): stdClass {
        $tenant = \core\di::get(tenant::class);
        $configmanager = \core\di::get(config_manager::class);

        $instances = [];

        // Purposes with role unlimited.
        $purposeconfigroleunlimited = $configmanager->get_purpose_config();
        $purposeswithtoolroleunlimited= [];
        foreach ($purposeconfigroleunlimited as $purpose => $instanceid) {
            if (!is_null($instanceid)) {
                $purposeswithtoolroleunlimited[] = $purpose;
            }
        }
        $purposesheadingroleunlimited = get_string('purposesheading', 'local_gamibot_manager', [
                'role' => get_string('role_unlimited', 'local_gamibot_manager'),
                'currentcount' => count($purposeswithtoolroleunlimited),
                'maxcount' => count($purposeconfigroleunlimited),
        ]);

        foreach (base_instance::get_all_instances() as $instance) {
            $purposesroleunlimited = [];
            foreach ($purposeconfigroleunlimited as $purpose => $instanceid) {
                if (intval($instanceid) === $instance->get_id()) {
                    $purposesroleunlimited[] = ['fullname' => get_string('pluginname', 'gbpurpose_' . $purpose)];
                }
            }

            $linkedname = $instance->is_enabled()
                    ? html_writer::link(new moodle_url('/local/gamibot_manager/edit_instance.php',
                            ['id' => $instance->get_id(), 'tenant' => $tenant->get_identifier()]), $instance->get_name())
                    : $instance->get_name();

            $instances[] = [
                    'name' => $linkedname,
                    'toolname' => get_string('pluginname', 'gbtool_' . $instance->get_connector()),
                    'model' => $instance->get_model() === base_instance::PRECONFIGURED_MODEL
                            ? get_string('preconfiguredmodel', 'local_gamibot_manager')
                            : $instance->get_model(),
                    'enabled' => $instance->is_enabled(),
                    'purposesroleunlimited' => $purposesroleunlimited,
                    'nopurposeslink' => html_writer::link(
                        new moodle_url('/local/gamibot_manager/purpose_config.php', []),
                        '<i class="fa fa-arrow-right"></i> ' . get_string('assignpurposes', 'local_gamibot_manager')
                    ),
            ];
        }
        return (object) [
                'tenant' => $tenant->get_identifier(),
                'purposesheadingroleunlimited' => $purposesheadingroleunlimited,
                'instances' => $instances,
        ];
    }
}
