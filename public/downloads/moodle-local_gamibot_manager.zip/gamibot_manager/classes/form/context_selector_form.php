<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_gamibot_manager\form;

use local_gamibot_manager\gamibot_manager_utils;
use local_gamibot_manager\local\access_manager;

defined('MOODLE_INTERNAL') || die;

global $CFG;
require_once($CFG->libdir . '/formslib.php');

/**
 * A form for selecting the correct context.
 *
 * @package    local_gamibot_manager
 * @copyright  2025 ISB Bayern
 * @author     Philipp Memmel
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class context_selector_form extends \moodleform {

    /**
     * Form definition.
     */
    public function definition() {
        global $USER;
        $mform = &$this->_form;
        $attributes = $mform->getAttributes();
        $attributes['class'] = $attributes['class'] . ' col-md-12';
        $mform->setAttributes($attributes);

        $enrolledcourses = enrol_get_all_users_courses($USER->id, false, 'id,shortname', 'shortname ASC');

        $maincontextoptions = [];
        foreach ($enrolledcourses as $course) {
            $coursecontext = \context_course::instance($course->id);
            if (has_capability('local/gamibot_manager:viewprompts', $coursecontext)) {
                $maincontextoptions[$coursecontext->id] = gamibot_manager_utils::get_context_displayname($coursecontext);
            }
        }

        $maincontextselect =
                $mform->createElement('select', 'contextid', get_string('choosecontext', 'local_gamibot_manager'), [],
                        ['onchange' => 'this.form.requestSubmit()']);
        foreach ($maincontextoptions as $key => $value) {
            $maincontextselect->addOption($value, $key);
        }

        $mform->addElement($maincontextselect);
    }

}
