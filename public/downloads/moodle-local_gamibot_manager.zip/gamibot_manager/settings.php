<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Settings for the local_gamibot_manager plugin.
 *
 * @package    local_gamibot_manager
 * @copyright  2024 ISB Bayern
 * @author     Philipp Memmel
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_gamibot_manager\local\admin_setting_configdate;

defined('MOODLE_INTERNAL') || die;

global $DB;

if ($hassiteconfig) {

    $aimanagercategory = new admin_category('local_gamibot_manager_settings',
            new lang_string('pluginname', 'local_gamibot_manager'));
    $ADMIN->add('localplugins', $aimanagercategory);

    $settings = new admin_settingpage('local_gamibot_manager', get_string('basicsettings', 'local_gamibot_manager'));
    $ADMIN->add('local_gamibot_manager_settings', $settings);

    /*$ingestionsettings = new admin_settingpage('local_gamibot_manager', get_string('ingestionsettings', 'local_gamibot_manager'));
    $ADMIN->add('local_gamibot_manager_settings', $ingestionsettings);*/

    if ($ADMIN->fulltree) {
        $settings->add(
                new admin_setting_heading('local_gamibot_manager/basicsettings',
                        get_string('basicsettings', 'local_gamibot_manager'),
                        get_string('basicsettingsdesc', 'local_gamibot_manager')));

        /*$settings->add(new admin_setting_configselect('local_gamibot_manager/tenantcolumn',
                new lang_string('tenantcolumn', 'local_gamibot_manager'),
                new lang_string('tenantcolumndesc', 'local_gamibot_manager'),
                'institution',
                [
                        'institution' => 'institution',
                        'department' => 'department',
                        'city' => 'city',
                ]
        ));*/

        $settings->add(new admin_setting_configcheckbox(
                'local_gamibot_manager/addnavigationentry',
                new lang_string('addnavigationentry', 'local_gamibot_manager'),
                new lang_string('addnavigationentrydesc', 'local_gamibot_manager'),
                1
        ));

        $settings->add(new admin_setting_configcheckbox(
                'local_gamibot_manager/verifyssl',
                new lang_string('verifyssl', 'local_gamibot_manager'),
                new lang_string('verifyssldesc', 'local_gamibot_manager'),
                1
        ));


        $settings->add(new admin_setting_configtext(
                'local_gamibot_manager/requesttimeout',
                new lang_string('requesttimeout', 'local_gamibot_manager'),
                new lang_string('requesttimeoutdesc', 'local_gamibot_manager'),
                '60'
        ));

        /*$settings->add(new admin_setting_confightmleditor(
                'local_gamibot_manager/termsofuse',
                new lang_string('termsofusesetting', 'local_gamibot_manager'),
                new lang_string('termsofusesettingdesc', 'local_gamibot_manager'),
                '',
                PARAM_RAW,
                60,
                20
        ));*/

        /*$roleids = get_roles_for_contextlevels(CONTEXT_SYSTEM);
        if (empty($roleids)) {
            $roles = [];
        } else {
            [$insql, $inparams] = $DB->get_in_or_equal($roleids, SQL_PARAMS_NAMED);
            $roles = $DB->get_records_select('role', "id $insql", $inparams, 'shortname');
        }
        $roles = role_fix_names($roles, null, ROLENAME_BOTH, true);
        $settings->add(new admin_setting_configmultiselect('local_gamibot_manager/legalroles',
                get_string('legalroles', 'local_gamibot_manager'),
                get_string('legalrolesdesc', 'local_gamibot_manager'),
                ['manager'],
                $roles
        ));

        $settings->add(new admin_setting_confightmleditor(
                'local_gamibot_manager/termsofuselegal',
                new lang_string('termsofuselegalsetting', 'local_gamibot_manager'),
                new lang_string('termsofuselegalsettingdesc', 'local_gamibot_manager'),
                '',
                PARAM_RAW,
                60,
                20
        ));*/

        /*$settings->add(new admin_setting_confightmleditor(
                'local_gamibot_manager/dataprocessing',
                new lang_string('dataprocessingsetting', 'local_gamibot_manager'),
                new lang_string('dataprocessingsettingdesc', 'local_gamibot_manager'),
                '',
                PARAM_RAW,
                60,
                20
        ));*/

        /*$settings->add(new admin_setting_configtext(
                'local_gamibot_manager/aiwarningurl',
                new lang_string('aiwarningurl', 'local_gamibot_manager'),
                new lang_string('aiwarningurldesc', 'local_gamibot_manager'),
                ''
        ));*/

        /*$settings->add(new admin_setting_configmultiselect('local_gamibot_manager/privilegedroles',
                get_string('privilegedroles', 'local_gamibot_manager'),
                get_string('privilegedrolesdesc', 'local_gamibot_manager'),
                ['manager'],
                $roles
        ));*/

        $settings->add(new admin_setting_configcheckbox('local_gamibot_manager/enablecleanuprequestlogtask',
            get_string('enablecleanuprequestlogtask', 'local_gamibot_manager'),
            get_string('enablecleanuprequestlogtaskdesc', 'local_gamibot_manager'),
        '0'
        ));

        $settings->add(new admin_setting_configdate('local_gamibot_manager/datawiperanonymizedate',
                get_string('datawiperanonymizedate', 'local_gamibot_manager'),
                get_string('datawiperanonymizedatedesc', 'local_gamibot_manager'),
                '1759269600'
        ));
        $settings->add(new admin_setting_configdate('local_gamibot_manager/datawiperdeletedate',
                get_string('datawiperdeletedate', 'local_gamibot_manager'),
                get_string('datawiperdeletedatedesc', 'local_gamibot_manager'),
                '1759269600'
        ));

        // Gami API endpoint (Gami API URL).
        $settings->add(new admin_setting_configtext(
            'local_gamibot_manager/gami_api_endpoint',
            get_string('gami_api_endpoint', 'local_gamibot_manager'),
            get_string('gami_api_endpoint_desc', 'local_gamibot_manager'),
            'https://gami-api.hub.inov-norte.ipp.pt',
            PARAM_URL
        ));

        // Shared secret used to sign Moodle → Gami API requests.
        $settings->add(new admin_setting_configtext(
            'local_gamibot_manager/gami_api_secret',
            get_string('gami_api_secret', 'local_gamibot_manager'),
            get_string('gami_api_secret_desc', 'local_gamibot_manager'),
            '',
            PARAM_ALPHANUMEXT
        ));

        // Webhook ingestion endpoint (LangFlow URL).
        $settings->add(new admin_setting_configtext(
            'local_gamibot_manager/ingestion_endpoint',
            get_string('ingestion_endpoint', 'local_gamibot_manager'),
            get_string('ingestion_endpoint_desc', 'local_gamibot_manager'),
            'https://langflow.hub.inov-norte.ipp.pt/api/v1/webhook/28021035-3987-478c-8e79-ac59b1a03f94',
            PARAM_URL
        ));

        // Shared secret used to sign Moodle → LangFlow requests.
        $settings->add(new admin_setting_configtext(
            'local_gamibot_manager/webhook_secret',
            get_string('webhook_secret', 'local_gamibot_manager'),
            get_string('webhook_secret_desc', 'local_gamibot_manager'),
            '',
            PARAM_ALPHANUMEXT
        ));

        // Number of questions in generated quizzes
        $settings->add(new admin_setting_configtext(
            'local_gamibot_manager/nr_of_questions',
            new lang_string('nr_of_questions', 'local_gamibot_manager'),
            new lang_string('nr_of_questions_desc', 'local_gamibot_manager'),
            '5',
            PARAM_INT
        ));
    }

    $gbtoolssettingpage =
            new admin_settingpage('gbtoolpluginsmanagement', get_string('subplugintype_gbtool_plural', 'local_gamibot_manager'));
    $gbtoolssettingpage->add(new \core_admin\admin\admin_setting_plugin_manager(
            'gbtool',
            \local_gamibot_manager\table\gbtools_admin_table::class,
            'gbtools_management',
            get_string('subplugintype_gbtool_plural', 'local_gamibot_manager')
    ));

    $gbpurposessettingpage =
            new admin_settingpage('gbpurposepluginsmanagement', get_string('subplugintype_gbpurpose_plural', 'local_gamibot_manager'));
    $gbpurposessettingpage->add(new \core_admin\admin\admin_setting_plugin_manager(
            'gbpurpose',
            \local_gamibot_manager\table\gbpurposes_admin_table::class,
            'gbpurposes_management',
            get_string('subplugintype_gbtool_plural', 'local_gamibot_manager')
    ));

    $ADMIN->add('local_gamibot_manager_settings', $gbtoolssettingpage);
    $ADMIN->add('local_gamibot_manager_settings', $gbpurposessettingpage);

    $ADMIN->add('local_gamibot_manager_settings', new admin_category('gbtoolplugins',
            new lang_string('gbtoolplugins', 'local_gamibot_manager')));
    $plugins = \core_plugin_manager::instance()->get_plugins_of_type('gbtool');
    foreach ($plugins as $plugin) {
        $plugin->load_settings($ADMIN, 'gbtoolplugins', $hassiteconfig);
    }

    $ADMIN->add('local_gamibot_manager_settings', new admin_category('gbpurposeplugins',
            new lang_string('gbpurposeplugins', 'local_gamibot_manager')));
    $plugins = \core_plugin_manager::instance()->get_plugins_of_type('gbpurpose');
    foreach ($plugins as $plugin) {
        $plugin->load_settings($ADMIN, 'gbpurposeplugins', $hassiteconfig);
    }
}
