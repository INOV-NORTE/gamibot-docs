<?php

function local_gamibot_manager_extend_navigation_course(
    navigation_node $parentnode,
    $course,
    $context
) {
    // 1. Security Check: Check for specific capability in the current course context
    if (!has_capability('local/gamibot_manager:viewprompts', $context)) {
        return;
    }
    $parentnode->add(
        get_string('viewprompts_menu_item', 'local_gamibot_manager'),
        new moodle_url('/local/gamibot_manager/view_prompts.php', array('contextid' => $context->id)),
        navigation_node::TYPE_SETTING,
        null,
        'local_gamibot_manager_view_prompts',
        new pix_icon('i/navigationitem', '')
    );
}
