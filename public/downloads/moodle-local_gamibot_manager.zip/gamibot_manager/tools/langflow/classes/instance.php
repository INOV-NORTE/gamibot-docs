<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace gbtool_langflow;

use local_gamibot_manager\base_instance;
use local_gamibot_manager\local\gbtool_option_temperature;
use stdClass;

/**
 * Instance class for the connector instance of gbtool_langflow.
 */
class instance extends base_instance {



    #[\Override]
    protected function extend_form_definition(\MoodleQuickForm $mform): void {
        $mform->removeElement('model');
    }

    #[\Override]
    protected function get_extended_formdata(): stdClass {
        $data = new stdClass();
        return $data;
    }

    #[\Override]
    protected function extend_validation(array $data, array $files): array {
        $errors = [];
        if (empty($data['endpoint'])) {
            $errors['endpoint'] = get_string('formvalidation_noendpoint', 'gbtool_langflow');;
        }
        return $errors;
    }

    #[\Override]
    protected function extend_store_formdata(stdClass $data): void {
    }
}
