<?php

defined('MOODLE_INTERNAL') || die();

/**
 * Perform post-installation tasks.
 *
 * @return bool true if the installation was successful, false otherwise.
 */
function xmldb_local_gamibot_manager_install() {
    global $DB;

    // Define the clarify tool
    $record = new stdClass();
    $record->name = 'Langflow - Clarify';
    $record->tenant = 'default';
    $record->connector = 'langflow';
    $record->model = 'preconfigured';
    $record->endpoint = 'https://langflow.hub.inov-norte.ipp.pt/api/v1/run/f0be7594-16a8-459e-ae96-8b79637fcbbb';
    $record->apikey = '';
    $record->domaininput = 'TextInput-8xdUH';
    $record->courseinput = 'TextInput-1NWCq';
    $record->timecreated = time();
    $record->timemodified = time();

    $clarifytoolid =  $DB->insert_record('local_gamibot_manager_instance', $record);

    // Define the summarize tool
    $record = new stdClass();
    $record->name = 'Langflow - Summarize';
    $record->tenant = 'default';
    $record->connector = 'langflow';
    $record->model = 'preconfigured';
    $record->endpoint = 'https://langflow.hub.inov-norte.ipp.pt/api/v1/run/28ec36b5-0432-4072-8293-607a6efe1c09';
    $record->apikey = '';
    $record->domaininput = 'TextInput-8xdUH';
    $record->courseinput = 'TextInput-1NWCq';
    $record->timecreated = time();
    $record->timemodified = time();

    $summarizetoolid =  $DB->insert_record('local_gamibot_manager_instance', $record);

    // Define the quiz tool
    $record = new stdClass();
    $record->name = 'Langflow - Quiz';
    $record->tenant = 'default';
    $record->connector = 'langflow';
    $record->model = 'preconfigured';
    $record->endpoint = 'https://langflow.hub.inov-norte.ipp.pt/api/v1/run/5fad50dc-438b-4deb-ad6d-274e5d1b8a6b';
    $record->apikey = '';
    $record->domaininput = 'TextInput-8xdUH';
    $record->courseinput = 'TextInput-1NWCq';
    $record->additionalinput1 = 'TextInput-VXxfq';
    $record->timecreated = time();
    $record->timemodified = time();

    $quiztoolid =  $DB->insert_record('local_gamibot_manager_instance', $record);

    \set_config('tenantenabled', true, 'local_gamibot_manager');

    \set_config(\local_gamibot_manager\base_purpose::get_purpose_tool_config_key('clarify'), $clarifytoolid, 'local_gamibot_manager');
    \set_config(\local_gamibot_manager\base_purpose::get_purpose_tool_config_key('summarize'), $summarizetoolid, 'local_gamibot_manager');
    \set_config(\local_gamibot_manager\base_purpose::get_purpose_tool_config_key('quiz'), $quiztoolid, 'local_gamibot_manager');

    return true;
}
