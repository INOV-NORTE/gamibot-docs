<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Configuration page for tenants.
 *
 * @package    local_gamibot_manager
 * @copyright  2025 Centro de Inovação Pedagógica P. Porto
 * @author     José C. Paiva
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_gamibot_manager\local\tenant_config_output_utils;
use local_gamibot_manager\output\tenantnavbar;

require_once(dirname(__FILE__) . '/../../config.php');
require_login();

global $CFG, $DB, $OUTPUT, $PAGE, $SESSION, $USER;

$purpose = required_param('purpose', PARAM_ALPHANUM);
$SESSION->local_gamibot_manager_statistics_purpose = $purpose;

tenant_config_output_utils::setup_tenant_config_page(new moodle_url('/local/gamibot_manager/purpose_statistics.php'));

$tenant = \core\di::get(\local_gamibot_manager\local\tenant::class);
require_capability('local/gamibot_manager:viewuserstatistics', $tenant->get_context());

if (!in_array($purpose, \local_gamibot_manager\base_purpose::get_all_purposes())) {
    throw new moodle_exception('exception_invalidpurpose', 'local_gamibot_manager');
}

echo $OUTPUT->header();
$currentpage = 'purpose_statistics.php?purpose=' . $purpose;
$tenantnavbar = new tenantnavbar($currentpage);
echo $OUTPUT->render($tenantnavbar);

$baseurl = new moodle_url('/local/gamibot_manager/purpose_statistics.php', ['purpose' => $purpose]);

echo $OUTPUT->heading(get_string('userstatistics', 'local_gamibot_manager'), 2, 'text-center');
echo $OUTPUT->heading(get_string('purpose', 'local_gamibot_manager') . ': '
    . get_string('pluginname', 'gbpurpose_' . $purpose), 4, 'text-center pb-3');

$tenantfield = get_config('local_gamibot_manager', 'tenantcolumn');
$recordscountsql = "SELECT COUNT(*) FROM {local_gamibot_manager_request_log} rl JOIN {user} u ON rl.userid = u.id"
        . " WHERE u." . $tenantfield . " = :tenant AND rl.purpose = :purpose";
$recordscountparams = ['tenant' => $tenant->get_sql_identifier(), 'purpose' => $purpose];
$recordscount = $DB->count_records_sql($recordscountsql, $recordscountparams);

if ($recordscount !== 0) {
    $uniqid = 'statistics-table-purpose-' . $purpose;

    echo html_writer::div(get_string('userwithusageonlyshown', 'local_gamibot_manager'));

    $table = new \local_gamibot_manager\table\userstats_table($uniqid);
    $table->out(30, false);
} else {
    echo html_writer::div(get_string('nodata', 'local_gamibot_manager'), 'alert alert-info');
}

echo $OUTPUT->footer();
