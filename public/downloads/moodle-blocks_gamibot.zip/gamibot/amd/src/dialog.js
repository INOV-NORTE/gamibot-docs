/* eslint-disable max-len */
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

import Modal from 'core/modal';
import * as externalServices from 'block_gamibot/webservices';
import Templates from 'core/templates';
import {
    alert as displayAlert,
    deleteCancelPromise,
    exception as displayException
} from 'core/notification';
import ModalEvents from 'core/modal_events';
import ModalForm from 'core_form/modalform';
import * as helper from 'block_gamibot/helper';
import * as manager from 'block_gamibot/gamibot_manager';
import {getString} from 'core/str';
import {renderWarningBox} from 'local_gamibot_manager/warningbox';
import {getAiConfig} from 'local_gamibot_manager/config';
import LocalStorage from 'core/localstorage';
import {escapeHTML, hash, scrollToBottom, selectPortugueseVoice, speakText} from './helper';
import badgeIcons from './badge-icons';

// Declare variables.
const VIEW_CHATWINDOW = 'block_gamibot_chatwindow';
const VIEW_OPENFULL = 'block_gamibot_openfull';
const MODAL_OPEN = 'block_gamibot_open';

// Modal.
let modal = {};
let strNewDialog;
let strToday;
let strYesterday;
let optionsForm = {};
let showOptions = false;
let badge;
let viewmode;
let modalopen = false;

// Current conversation.
let conversation = {
    id: 0,
    messages: [],
};
// All conversations.
let allConversations = [];

// User ID.
let userid = 0;
// Block context id.
let contextid = 0;
// Purpose selected.
let purpose = 'clarify';
// First load.
let firstLoad = true;
// Loading screen active
let loading = false;
// AI in process of answering.
let aiAtWork = false;

// Gamibot configuration
let gamibotConfig = {};
let chatConfig = {};

// Gamification data
let statsList = [];
let badgesList = [];
let topTopics = [];
let strugglingTopics = [];

class DialogModal extends Modal {
    static TYPE = "block_gamibot/modal_shell";
    static TEMPLATE = "block_gamibot/modal_shell";

    configure(modalConfig) {
        // Show this modal on instantiation.
        modalConfig.show = false;

        // Remove from the DOM on close.
        modalConfig.removeOnClose = false;

        modalConfig.isVerticallyCentered = false;

        super.configure(modalConfig);
    }

    hide() {
        super.hide();
        // Keep track of state, to restrict changes to block_gamibot modal.
        modalopen = false;
        const body = document.querySelector('body');
        body.classList.remove(MODAL_OPEN);
    }
}

export const init = async(params) => {
    // Read params.
    userid = params.userid;
    contextid = params.contextid;
    strNewDialog = params.new;
    showOptions = params.showoptions;
    badge = params.badge;
    // Disable badge.
    badge = false;

    // Get configuration.
    gamibotConfig = await getAiConfig(contextid, null, ['clarify', 'quiz', 'summarize']);
    chatConfig = gamibotConfig.purposes[0];

    // Build chat dialog modal.
    modal = await DialogModal.create({
        templateContext: {
            title: strNewDialog,
            badge: badge,
            showOptions: showOptions
        },
    });

    // Add class for styling when modal is displayed.
    modal.getRoot().on('modal:shown', function(e) {
        e.target.classList.add("block_gamibot_modal");
    });

    // Conditionally prevent outside click event.
    modal.getRoot().on(ModalEvents.outsideClick, event => {
        checkOutsideClick(event);
    });

    // Check and set viewmode.
    setView();

    // Ensure voices are loaded before we try to select one
    if ('speechSynthesis' in window) {
        selectPortugueseVoice();
        if (window.speechSynthesis.onvoiceschanged !== undefined) {
            window.speechSynthesis.onvoiceschanged = selectPortugueseVoice;
        }
    }

    // Attach listener to the ai button to call modal.
    let button = document.getElementById('gamibot_button');
    button.addEventListener('mousedown', async() => {
        showModal(params);
    });

    // Get strings.
    strToday = await getString('today', 'core');
    strYesterday = await getString('yesterday', 'block_gamibot');

    // Create a MediaQueryList object to check for small screens.
    const mediaQuery = window.matchMedia("(max-width: 576px)");

    // Attach the event listener to handle changes.
    mediaQuery.addEventListener('change', handleScreenWidthChange);

    // Initial check for screenwidth.
    if (window.innerWidth <= 576) {
        setView(VIEW_OPENFULL);
    }
};

/**
 * Activate clarification mode.
 */
async function activateClarificationMode() {
    purpose = "clarify";
    chatConfig = gamibotConfig.purposes[0];
    setModalHeader(true);
    await showChat();
    // TODO
}

/**
 * Activate quiz chat mode.
 */
async function activateQuizChatMode() {
    purpose = "quiz";
    chatConfig = gamibotConfig.purposes[1];
    setModalHeader(true);
    await showChat();
    // TODO
}

/**
 * Activate summary mode.
 */
async function activateSummaryMode() {
    purpose = "summarize";
    chatConfig = gamibotConfig.purposes[2];
    setModalHeader(true);
    await showChat();
    // TODO
}

/**
 * Show gamibot modal.
 */
async function showModal() {
    // Switch for repeated clicking.
    if (modalopen) {
        modal.hide();
        return;
    }

    // Show modal.
    await modal.show();
    modalopen = true;
    const body = document.querySelector('body');
    body.classList.add(MODAL_OPEN);

    if (firstLoad) {
        await showInitialPage();

        // Views.
        setView();

        firstLoad = false;
    }
}


/**
 * Webservice Get all conversations.
 */
// eslint-disable-next-line no-unused-vars
const getConversations = async() => {
    try {
        allConversations = await externalServices.getAllConversations(userid, contextid);
    } catch (error) {
        displayException(error);
    }
};

/**
 * Enable/disable loading screen
 * @param {boolean} state is it loading?
 */
const setLoading = (state) => {
    loading = state;

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container) {
        if (loading) {
            container.classList.add('loading');
            const loadingIndicator = document.createElement("div");
            loadingIndicator.classList.add("loading-indicator");
            loadingIndicator.innerHTML = '<div class="spinner-border text-primary" role="status"></div>';
            container.appendChild(loadingIndicator);
        } else {
            container.classList.remove('loading');
            const loadingIndicator = document.querySelector("div.loading-indicator");
            if (loadingIndicator) {
                loadingIndicator.remove();
            }
        }
    }
};

/**
 * Function to set conversation.
 * @param {*} id
 */
const showConversation = async(id = 0) => {
    // Dissallow changing conversations when question running.
    if (aiAtWork) {
        return;
    }
    // Change conversation or get last conversation.
    if (id !== 0) {
        // Set selected conversation.
        conversation = allConversations.find(x => x.id === id);
    } else if (typeof allConversations[0] !== 'undefined') {
        // Set last conversation.
        conversation = allConversations.at(allConversations.length - 1);
    } else if (allConversations.length === 0) {
        // Last conversation has been deleted.
        newDialog(true);
    }
    clearMessages();
    setModalHeader();
    await showMessages();
    helper.renderMathjax();
};
// Make globally accessible since it is used to show history in dropdownmenuitem.mustache.
document.showConversation = showConversation;

/**
 * Reset chat ID
 *
 * @param {string} question Question sent by user
 */
async function resetChatId(question) {
    try {
        let idresult = await externalServices.getNewConversationId(contextid);
        conversation.id = idresult.id;
        conversation.purpose = purpose;
        conversation.timecreated = Math.floor(Date.now() / 1000);
        setModalHeader(escapeHTML(question));
    } catch (error) {
        displayException(error);
    }
}

/**
 * Send input to ai connector.
 * @param {*} question
 */
const enterQuestion = async(question) => {

    // Deny changing dialogs until answer present?
    if (question === '') {
        aiAtWork = false;
        return;
    }
    const message = await userAllowed();
    if (message !== '') {
        aiAtWork = false;
        return;
    }

    // Add to conversation, answer not yet available.
    showMessage(question, 'self', false);

    // For the first message, add the personaprompt, even if empty.
    // Since we dont know if the personaPrompt was changed, always replace it.
    /*if (typeof conversation.messages[0] == 'undefined' || conversation.messages[0].sender !== 'system') {
        conversation.messages.unshift({
            'message': personaPrompt,
            'sender': 'system'
        });
    } else {
        // Replace personaPrompt.
        conversation.messages[0] = {
            'message': personaPrompt,
            'sender': 'system'
        };
    }*/

    // Check history for length limit.
    let convHistory = [...conversation.messages];

    // Since some models cant handle an empty system message, remove from convHistory.
    /*if (personaPrompt.trim() === '' && convHistory[0].sender === 'system') {
        convHistory.shift();
    }*/
    // Options, with conversation history.
    const options = {
        'component': 'block_gamibot',
        'conversationcontext': convHistory
    };

    // For a new conversation, get an id.
    if (!conversation?.id || conversation.id === 0) {
        await resetChatId(question, options);
        //noptions.forcenewitemid = true;
    }

    // Pass itemid / conversationid.
    options.itemid = conversation.id;

    // Send to local_gamibot_manager.
    let requestresult = await manager.askLocalGamibotManager(purpose, question, contextid, options);

    // displayAlert(requestresult.result);

    // Handle errors.
    if (requestresult.code != 200) {
        requestresult = await errorHandling(requestresult, question, contextid, options);
    }

    // Write back answer.
    await showReply(requestresult.result);

    // Render mathjax.
    helper.renderMathjax();

    // Ai is done.
    aiAtWork = false;

    // Save new question and answer.
    if (requestresult.code == 200) {
        // If new conversation, sanitize the prompt for modal title and history.
        if (conversation.messages.length == 0) {
            question = escapeHTML(question);
        }
        saveConversationLocally(question, requestresult.result);
    }

    // update stats asynchronously
    updateUserStatsInfo();
};

/**
 * Update user stats information.
 *
 * @returns {Promise<void>}
 */
const updateUserStatsInfo = async () => {
    let userStats;
    try {
        const response = await manager.getUserStats(contextid, []);
        userStats = JSON.parse(response.result);
    } catch (error) {
        displayAlert('Error while retrieving user stats from API: ', error);
        return;
    }

    statsList = {
        conversations: (
            userStats.stats.clarifyConversations +
            userStats.stats.quizConversations +
            userStats.stats.summarizeConversations
        ),
        minutes: Math.round(userStats.stats.totalTimeMs / (60 * 1000)),
        points: userStats.xp,
        badges: userStats.badges.filter(badge => badge.level >= 1).length,
        doubts: userStats.stats.clarifyConversations,
        quizzes: userStats.stats.quizConversations,
        summaries: userStats.stats.summarizeConversations,
    };

    const badges = userStats.badges.sort((a, b) => {
        if (a.level > b.level) {
            return -1;
        } else if (a.level < b.level) {
            return 1;
        }
        return b.levelProgress - a.levelProgress;
    });
    badgesList = badges.map((badge, index) => ({
        id: badge.badgeId,
        name: badge.badge.title,
        currentLevel: badge.level,
        unlockedClass: badge.level >= 1 ? 'badge-unlocked' : 'badge-locked',
        unlockedLabel: badge.level >= 1 ? 'desbloqueado' : 'bloqueado',
        image: badgeIcons[badge.badge.icon],
        extra: index >= 3,
        progress: badge.levelProgress,
    }));

    topTopics = userStats.topicProgresses.filter(t => t.completed || t.progressPercent >= 80);
    strugglingTopics = userStats.topicProgresses.filter(t => !t.completed && t.progressPercent < 80);
};

/**
 * Add interaction buttons to message.
 * @param {string} id Message id
 * @param {string} text Message text
 * @param {Element} messageMeta Message meta element
 */
function addInteractionButtons(id, text, messageMeta) {
    const actionsDiv = document.createElement('div');
    actionsDiv.classList.add('actions');

    const clipboardButton = document.createElement('button');
    clipboardButton.classList.add('btn', 'btn-icon', 'btn-clipboard');
    clipboardButton.setAttribute('title', 'Copiar resposta');
    clipboardButton.setAttribute('aria-hidden', 'true');
    clipboardButton.setAttribute('data-action', 'copytoclipboard');
    clipboardButton.setAttribute('data-clipboard-target', `#${id}`);
    clipboardButton.setAttribute('data-clipboard-success-message', 'Resposta copiada!');
    clipboardButton.innerHTML = '<i class="fa fa-clipboard"></i>';
    actionsDiv.appendChild(clipboardButton);

    if ('speechSynthesis' in window) {
        const audioButton = document.createElement('button');
        audioButton.classList.add('btn', 'btn-icon', 'btn-voice');
        audioButton.setAttribute('title', 'Reproduzir mensagem de voz');
        audioButton.setAttribute('aria-hidden', 'true');
        audioButton.innerHTML = '<i class="fa fa-volume-up"></i>';
        audioButton.addEventListener('click', () => {
            selectPortugueseVoice();
            speakText(text, audioButton);
        });
        actionsDiv.appendChild(audioButton);
    }

    messageMeta.appendChild(actionsDiv);
}

/**
 * Render reply.
 * @param {string} text
 */
const showReply = async(text) => {
    let isQuiz = false;
    let isFeedback = false;
    let quizData = null;
    let feedbackData = null;

    if (purpose === 'quiz' && QuizManager.status === 0) {
        try {
            const extracted = extractJsonFromMessage(text);

            if (extracted?.quiz) {
                isQuiz = true;
                quizData = extracted;
            } else if (extracted?.feedback) {
                isFeedback = true;
                feedbackData = extracted.feedback;
            }
            // eslint-disable-next-line no-empty
        } catch (error) { }
    } else if (purpose === 'quiz' && QuizManager.status === 2) {
        isFeedback = true;
        feedbackData = text;
    }

    if (isQuiz) {
        // eslint-disable-next-line no-console
        console.log(quizData);
        if (!quizData?.quiz && Array.isArray(quizData)) {
            quizData = {quiz: quizData};
        }

        if (quizData?.quiz) {
            QuizManager.loadQuizData(quizData);
            await showQuiz();

            let awaitdivs = document.querySelectorAll('.block_gamibot_modal .awaitanswer');
            if (awaitdivs.length > 0) {
                const awaitdiv = awaitdivs[awaitdivs.length - 1];
                awaitdiv.classList.remove('awaitanswer');
            }

            return;
        }
    }

    if (isFeedback) {
        QuizManager.setFeedback(feedbackData);
        await showQuizFeedback();

        let awaitdivs = document.querySelectorAll('.block_gamibot_modal .awaitanswer');
        if (awaitdivs.length > 0) {
            const awaitdiv = awaitdivs[awaitdivs.length - 1];
            awaitdiv.classList.remove('awaitanswer');
        }

        return;
    }

    // Get textblock.
    let fields = document.querySelectorAll('.block_gamibot_modal .awaitanswer .text');
    const field = fields[fields.length - 1];
    // Render the reply.
    // field.innerHTML = text;
    const id = `ai-reply-${Date.now()}`;
    const {html, js} = await Templates.renderForPromise('block_gamibot/reply', {id, text});
    Templates.replaceNodeContents(field, html, js);
    field.classList.remove('small');

    // Remove awaitanswer class.
    let awaitdivs = document.querySelectorAll('.block_gamibot_modal .awaitanswer');
    if (awaitdivs.length > 0) {
        const awaitdiv = awaitdivs[awaitdivs.length - 1];
        awaitdiv.classList.remove('awaitanswer');
    }

    const timecreated = Math.floor(Date.now() / 1000);
    const date = new Date(timecreated * 1000);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const formattedTime = `${hours}:${minutes}`;

    const messageMeta = document.createElement('div');
    messageMeta.classList.add('message-meta');

    const timestampSpan = document.createElement('span');
    timestampSpan.classList.add('timestamp');
    timestampSpan.textContent = formattedTime;
    messageMeta.appendChild(timestampSpan);

    addInteractionButtons(id, text, messageMeta);

    const messageContent = field.closest('.content');
    messageContent.appendChild(messageMeta);

    // Check if answer is smaller than the viewport, if so scroll to bottom.
    const container = document.querySelector('.block_gamibot-output-wrapper');
    if (field.scrollHeight < container.clientHeight) {
        scrollToBottom();
    }
};

const showMessages = async() => {
    for (const item of conversation.messages) {
        await showMessage(item.message, item.sender);
    }
};

/**
 * Show answer from local_gamibot_manager.
 * @param {*} text
 * @param {*} sender User or Ai
 * @param {*} answer Is answer in history
 * @param {*} timecreated hh:mm when message was created
 */
const showMessage = async(text, sender = '', answer = true, timecreated = null) => {
    // Skip if sender is system.
    if (sender === 'system') {
        return;
    }
    // Imitate bool for message.mustache logic {{#sender}}.
    if (sender === 'ai') {
        sender = '';
    }
    // Escape chars for immediate rendering.
    if (!answer) {
        text = escapeHTML(text);
    }

    if (!timecreated) {
        timecreated = Math.floor(Date.now() / 1000);
    }

    const date = new Date(timecreated * 1000);
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const formattedTime = `${hours}:${minutes}`;

    const id = `${sender === '' ? 'ai' : sender}-message-${Date.now()}`;

    const templateData = {
        "id": id,
        "sender": sender,
        "content": text,
        "answer": answer,
        "timecreated": formattedTime
    };
    // Call the function to load and render our template.
    const {html, js} = await Templates.renderForPromise('block_gamibot/message', templateData);
    await Templates.appendNodeContents('.block_gamibot-output', html, js);

    // Scroll the modal content to the bottom.
    helper.scrollToBottom();

    return id;
};

/**
 * Create a new / reset dialog.
 * @param {bool} deleted
 */
const newDialog = async(deleted = false) => {
    if (aiAtWork) {
        return;
    }
    // Add current convo local representation, if not already there.
    if (allConversations.find(x => x.id === conversation.id) === undefined && !deleted) {
        allConversations.push(conversation);
    }
    // Reset local conservation.
    conversation = {
        id: 0,
        messages: [],
    };

    clearMessages();
    setModalHeader(strNewDialog);
    helper.focustextarea();
};

/**
 * Delete /hide current dialog.
 */
const deleteCurrentDialog = () => {
    deleteCancelPromise(
        getString('delete', 'block_gamibot'),
        getString('deletewarning', 'block_gamibot'),
    ).then(async() => {
        if (conversation.id !== 0) {
            try {
                const deleted = await externalServices.deleteConversation(contextid, userid, conversation.id);
                if (deleted) {
                    removeFromHistory();
                    await showConversation();
                }
            } catch (error) {
                displayException(error);
            }
        }
    }).catch(() => {
    });
};

/**
 * Attaches a click event listener to the back button.
 *
 * @param {Function} callback - the function to execute when the back button is clicked
 */
const addBackButtonListener = (callback) => {
    const backButton = document.querySelector('.block_gamibot_backlink');
    if (backButton) {
        const newButton = backButton.cloneNode(true);
        backButton.parentNode.replaceChild(newButton, backButton);

        newButton.addEventListener('click', () => {
            callback();
        });
    }
};

/**
 * Show initial screen (first time using the chatbot)
 */
const showInitialPage = async() => {
    setLoading(false);

    const backButton = document.querySelector('.block_gamibot_backlink');
    if (backButton) {
        backButton.classList.add('hidden');
    }

    addBackButtonListener(() => {
        setModalHeader();
    });

    const modal = document.querySelector('.block_gamibot_modal');
    if (modal) {
        modal.classList.remove('onmenupage', 'onbadgespage', 'onchatpage', 'onhistorypage', 'onquizpage');
        modal.classList.add('oninitialpage');
    }

    const outputContainer = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (outputContainer) {
        outputContainer.innerHTML = '';
    }

    const templateData = {
        globals: {
            config: {
                wwwroot: window.M?.cfg?.wwwroot || ''
            }
        }
    };

    const {html, js} = await Templates.renderForPromise('block_gamibot/initialpage', templateData);
    await Templates.appendNodeContents('.block_gamibot_modal .block_gamibot-dialog', html, js);

    const quizBtn = document.querySelector('.btn-quiz');
    if (quizBtn) {
        quizBtn.addEventListener('click', async(e) => {
            e.preventDefault();
            await removeLastConversation();
            await activateQuizChatMode();

            // await api.addUserQuiz(courseid, userid);
        });
    }

    const summarizeBtn = document.querySelector('.btn-summarize');
    if (summarizeBtn) {
        summarizeBtn.addEventListener('click', async(e) => {
            e.preventDefault();
            await removeLastConversation();
            await activateSummaryMode();

            // await api.addUserSummary(courseid, userid);
        });
    }

    const clarifyBtn = document.querySelector('.btn-clarify');
    if (clarifyBtn) {
        clarifyBtn.addEventListener('click', async(e) => {
            e.preventDefault();
            await removeLastConversation();
            await activateClarificationMode();

            // await api.addUserDoubt(courseid, userid);
        });
    }

    const statsBtn = document.querySelector('.btn-stats');
    if (statsBtn) {
        statsBtn.addEventListener('click', async() => {
            await showMenu();
        });
    }

    setModalHeader();
};

/**
 * Show menu screen
 */
const showMenu = async() => {
    setLoading(false);

    const backButton = document.querySelector('.block_gamibot_backlink');
    if (backButton) {
        backButton.classList.remove('hidden');
    }

    await updateUserStatsInfo();

    const templateDate = {
        title: "Menu",
        badges: badgesList,
        stats: statsList,
        topHighTopics: topTopics,
        topLowTopics: strugglingTopics
    };

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container) {
        container.innerHTML = '';
        container.classList.remove('oninitialpage', 'onbadgespage', 'onchatpage', 'onhistorypage', 'onquizpage');
        container.classList.add('onmenupage');

        const {html, js} = await Templates.renderForPromise('block_gamibot/menu', templateDate);
        await Templates.appendNodeContents('.block_gamibot_modal .block_gamibot-dialog', html, js);

        const moreBadgesBtn = document.querySelector('.more-badges-btn');
        if (moreBadgesBtn) {
            moreBadgesBtn.addEventListener('click', async(e) => {
                e.preventDefault();
                await showBadges();
            });
        }

        const badgesCount = document.querySelector('.badges-count');
        if (badgesCount) {
            badgesCount.addEventListener('click', async(e) => {
                e.preventDefault();
                await showBadges();
            });
        }

        /*const newConversationBtn = document.querySelector('.newconversation-btn');
        if (newConversationBtn) {
            newConversationBtn.addEventListener('click', async() => {
                await showPurposeSelection();
            });
        }*/

        addBackButtonListener(async() => {
            await showInitialPage();
        });
    }
};

/**
 * Show badges screen
 */
const showBadges = async() => {
    setLoading(false);

    const backButton = document.querySelector('.block_gamibot_backlink');
    if (backButton) {
        backButton.classList.remove('hidden');
    }

    const templateData = {
        title: 'Badges',
        badges: badgesList,
    };

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container) {
        container.innerHTML = '';
        container.classList.remove('onmenupage', 'oninitialpage', 'onchatpage', 'onhistorypage', 'onquizpage');
        container.classList.add('onbadgespage');
    }

    const {html, js} = await Templates.renderForPromise('block_gamibot/badges', templateData);
    await Templates.appendNodeContents('.block_gamibot_modal .block_gamibot-dialog', html, js);

    addBackButtonListener(async() => {
        await showMenu();
    });
};

/**
 * Show chat screen
 */
const showChat = async() => {
    setLoading(false);

    const backButton = document.querySelector('.block_gamibot_backlink');
    if (backButton) {
        backButton.classList.remove('hidden');
    }

    const templateData = {
        title: 'Chat'
    };

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container) {
        container.innerHTML = '';
        container.classList.remove('onmenupage', 'oninitialpage', 'onbadgespage', 'onhistorypage', 'onquizpage');
        container.classList.add('onchatpage');
    }

    const {html, js} = await Templates.renderForPromise('block_gamibot/dialog_modal', templateData);
    container.innerHTML = html;
    if (js) {
        await Templates.executeJS(js);
    }

    // Add a listener for input submission.
    const textarea = document.getElementById('block_gamibot-input-id');
    if (textarea) {
        addTextareaListener(textarea);
    }
    const button = document.getElementById('block_gamibot-submit-id');
    if (button) {
        button.addEventListener('click', (event) => {
            clickSubmitButton(event);
        });
    }

    // Load conversations.
    // await getConversations();
    // Show last or selected conversation.
    // await showConversation();

    const btnNewDialog = document.getElementById('block_gamibot_new_dialog');
    const btnDeleteDialog = document.getElementById('block_gamibot_delete_dialog');

    await newDialog();
    btnNewDialog?.addEventListener('click', () => newDialog());
    btnDeleteDialog?.addEventListener('click', () => deleteCurrentDialog());

    const btnShowHistory = document.getElementById('block_gamibot_show_history');
    btnShowHistory?.addEventListener('click', () => showHistory());

    const btnOptions = document.getElementById('block_gamibot_options');
    btnOptions?.addEventListener('click', () => showOptionsModal());

    // Show warning if needed.
    const warningBoxSelector = '.local_gamibot_manager-ai-warning';
    if (document.querySelector(warningBoxSelector)) {
        await renderWarningBox(warningBoxSelector);
    }

    // Check permissions
    const message = await userAllowed();
    if (message !== '') {
        const notice = await getString('notice', 'block_gamibot');
        await displayAlert(notice, message);
    }

    if (purpose === 'clarify') {
        const text = 'Olá! Como posso ajudar-te com a matéria?';
        const id = await showMessage(text, 'ai');
        const messageMeta = document.querySelector(`#${id} + .message-meta`);
        addInteractionButtons(id, text, messageMeta);
    } else if (purpose === 'summarize') {
        const text = 'Olá! Que tópico da matéria queres que resuma?';
        const id = await showMessage(text, 'ai');
        const messageMeta = document.querySelector(`#${id} + .message-meta`);
        addInteractionButtons(id, text, messageMeta);
    } else if (purpose === 'quiz') {
        const text = 'Olá! Diz-me sobre qual tópico queres testar os teus conhecimentos e se preferes \'Verdadeiro/Falso\' ou \'Escolha Múltipla\'?';
        const id = await showMessage(text, 'ai');
        const messageMeta = document.querySelector(`#${id} + .message-meta`);
        addInteractionButtons(id, text, messageMeta);
    }

    addBackButtonListener(async() => {
        await showInitialPage();
    });

    helper.focustextarea();
};
/**
 * Extract the quiz from the chatbot message (JSON)
 * @param {string} message - The chatbot message containing the JSON quiz data.
 */
const extractJsonFromMessage = (message) => {
    let jsonMatch = message.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
    if (jsonMatch) {
        return JSON.parse(jsonMatch[1]);
    }
    jsonMatch = message.match(/<pre><code(?:\s+class="json")?>\s*([\s\S]*?)\s*<\/code><\/pre>/i);
    if (jsonMatch) {
        return JSON.parse(jsonMatch[1]);
    }
    return null;
};

/**
 * Controls the quiz progress
 */
const QuizManager = {
    status: 0, // 0 - uninitialized, 1 - running, 2 - finished
    topicId: undefined,
    userAnswers: [],
    quizData: [],
    currentIndex: 0,
    lives: 3,
    lastAnswer: {
        correct: false,
        feedback: '',
        correctOption: undefined,
        option: null
    },
    feedback: {
        resumo: '',
        dicas: []
    },
    loadQuizData(data) {
        // Const response = await fetch(M.cfg.wwwroot + '/blocks/gamibot/tests/multiple_choice_quiz.json');
        // const response = await fetch(M.cfg.wwwroot + '/blocks/gamibot/tests/true_false_quiz.json');
        this.quizData = data.quiz.questions;
        this.status = 1;
        this.topicId = data.quiz.module;
        this.currentIndex = 0;
        this.lives = 3;
        this.lastAnswer = {
            correct: false,
            feedback: '',
            correctOption: undefined,
            option: null
        };
    },
    getCurrentQuestion() {
        return this.quizData[this.currentIndex];
    },
    async registerAnswer(index) {
        const question = this.getCurrentQuestion();

        const selectedOption = question.options[index];

        let correctOption;
        if (!selectedOption.correct) {
            correctOption = question.options.find(opt => opt.correct);
            this.lives--;
            if (this.lives === 0) {
                this.status = 2;
            }
        } else {
            correctOption = selectedOption;
        }

        this.lastAnswer = {
            correct: selectedOption.correct,
            feedback: selectedOption.feedback,
            correctOption: selectedOption.correct ? undefined : correctOption,
            option: selectedOption
        };

        this.userAnswers.push(this.lastAnswer);

        if (this.userAnswers.length >= this.quizData.length) {
            this.status = 2;
        }
    },
    hasNext() {
        return this.currentIndex + 1 < this.quizData.length;
    },
    nextQuestion() {
        this.currentIndex++;
    },
    reset() {
        this.status = 0;
        this.userAnswers = [];
        this.currentIndex = 0;
        this.lives = 3;
        this.lastAnswer = {
            correct: false,
            feedback: '',
            correctOption: undefined,
            option: null
        };
    },
    getAnswersSummary() {
        return this.userAnswers
            .map((answer, index) => `${index + 1}. ${answer.option.text}`)
            .join('\n\n');
    },
    async sendAnswersToChatbot() {
        try {
            const points = this.userAnswers.filter((answer) => answer.correct).length;
            await manager.submitQuizScore(points, this.quizData.length, this.topicId, contextid, {
                'component': 'block_gamibot',
                'itemid': conversation.id
            });
        } catch (e) {
            displayAlert(e.result);
        }

        const message = `Respostas:\n\n${this.getAnswersSummary()}`;
        await enterQuestion(message);
    },
    setFeedback(feedbackData) {
        this.feedback = feedbackData;
    }
};

/**
 * Updates the lives in the UI
 */
function updateQuizLives() {
    const hearts = document.querySelectorAll('.quiz-lives .fa-heart');
    hearts.forEach((heart, index) => {
        if (index < QuizManager.lives) {
            heart.classList.remove('fa-heart-o');
            heart.classList.add('fa-heart');
        } else {
            heart.classList.remove('fa-heart');
            heart.classList.add('fa-heart-o');
        }
    });
}

/**
 * Show quiz
 */
const showQuiz = async() => {
    setLoading(false);

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container) {
        container.innerHTML = '';
        container.classList.remove('onmenupage', 'oninitialpage', 'onbadgespage', 'onhistorypage', 'onchatpage');
        container.classList.add('onquizpage');
    }

    const currentQuestion = QuizManager.getCurrentQuestion();
    const templateData = {
        current: QuizManager.currentIndex + 1,
        total: QuizManager.quizData.length,
        questionText: currentQuestion.question_text,
        options: currentQuestion.options.map((opt, i) => ({
            index: i,
            ...opt
        })),
    };

    const {html, js} = await Templates.renderForPromise('block_gamibot/quiz', templateData);
    await Templates.appendNodeContents('.block_gamibot_modal .block_gamibot-dialog', html, js);

    updateQuizLives();

    addBackButtonListener(async() => {
        QuizManager.reset();
        await showChat();
    });

    document.querySelectorAll('.answer-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.answer-btn').forEach(b => b.classList.remove('selected'));
            btn.classList.add('selected');
        });
    });

    const confirmationBtn = document.querySelector('.quiz-confirmation-btn');
    confirmationBtn.addEventListener('click', async(e) => {
        e.preventDefault();
        const selected = document.querySelector('.answer-btn.selected');
        if (!selected) {
            return;
        }

        const userAnswer = parseInt(selected.dataset.index);
        await QuizManager.registerAnswer(userAnswer);

        await showQuizModal();
    });
};

/**
 * Show feedback modals during the quiz
 */
const showQuizModal = async() => {
    const modalContainer = document.querySelector('.block_gamibot_modal .modal-content');
    if (!modalContainer) {
        return;
    }

    const {correct, feedback, option, correctOption} = QuizManager.lastAnswer;

    const templateData = {
        correct,
        feedback,
        correctOptionText: correct ? option.text : correctOption.text
    };

    const {html, js} = await Templates.renderForPromise('block_gamibot/quiz_modal', templateData);
    const wrapper = document.createElement('div');
    wrapper.classList.add('quiz-modal-wrapper');
    wrapper.innerHTML = html;

    modalContainer.appendChild(wrapper);

    if (js) {
        await Templates.executeJS(js);
    }

    updateQuizLives();

    const quizModalBtn = document.querySelector('.quiz-modal-btn');
    quizModalBtn.addEventListener('click', async(e) => {
        e.preventDefault();
        wrapper.remove();

        if (QuizManager.lives <= 0) {
            await new Promise(resolve => setTimeout(resolve, 800));
            wrapper.remove();

            setLoading(true);
            await QuizManager.sendAnswersToChatbot();
            await showQuizFeedback();
            setLoading(false);

            return;
        }

        if (QuizManager.hasNext()) {
            QuizManager.nextQuestion();
            await showQuiz();
        } else {
            setLoading(true);
            await QuizManager.sendAnswersToChatbot();
            await showQuizFeedback();
            setLoading(false);
        }
    });
};

/**
 * Show feedback at the end of the quiz
 *
 */
const showQuizFeedback = async() => {
    const templateData = {
        title: 'Quiz Feedback',
        feedback: QuizManager.feedback,
        points: QuizManager.userAnswers.filter((answer) => answer.correct).length,
        totalPoints: QuizManager.quizData.length,
    };

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container) {
        container.innerHTML = '';
        container.classList.remove('onmenupage', 'oninitialpage', 'onbadgespage', 'onhistorypage', 'onchatpage');
        container.classList.add('onquizpage');
    }

    const {html, js} = await Templates.renderForPromise('block_gamibot/quiz_feedback', templateData);
    await Templates.appendNodeContents('.block_gamibot_modal .block_gamibot-dialog', html, js);

    updateQuizLives();

    addBackButtonListener(async() => {
        QuizManager.reset();
        await showInitialPage();
    });

    document.addEventListener('click', async(e) => {
        const target = e.target.closest('.quiz-close-btn');
        if (target) {
            e.preventDefault();
            QuizManager.reset();
            await showMenu();
        }
    });
};

/**
 * Show conversation history.
 */
const showHistory = async() => {
    setLoading(false);

    // Add current convo local representation, if not already there.
    if (allConversations.find(x => x.id === conversation.id) === undefined) {
        allConversations.push(conversation);
    }

    clearMessages(true);
    const btnBacklink = document.getElementById('block_gamibot_backlink');
    btnBacklink.addEventListener('click', async() => {
        if (conversation.id !== 0) {
            await showConversation(conversation.id);
        } else {
            newDialog();
            clearMessages();
        }
        setModalHeader();
    });

    // Set modal class to hide info about ratelimits and infobox.
    let modal = document.querySelector('.block_gamibot_modal');
    modal.classList.add('onhistorypage');

    // Iterate over conversations and group by date.
    let groupedByDate = {};
    allConversations.forEach((convo) => {

        if (typeof convo.messages[0] !== 'undefined') {
            // Get first prompt for title.
            let title = '';
            if (convo.messages[0].sender == 'system') {
                title = convo.messages[1].message;
            } else {
                title = convo.messages[0].message;
            }

            // Get date and sort convos into a date array.
            const now = new Date();
            const date = new Date(convo.timecreated * 1000);
            const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
            const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
            const twoWeeksAgo = new Date(now);
            twoWeeksAgo.setDate(now.getDate() - 14);

            const options = {weekday: 'long', day: '2-digit', month: '2-digit'};
            const monthOptions = {month: 'long', year: '2-digit'};

            // Create a date string.
            let dateString = '';
            if (date >= today) {
                dateString = strToday;
            } else if (date >= yesterday) {
                dateString = strYesterday;
            } else if (date >= twoWeeksAgo) {
                dateString = date.toLocaleDateString(undefined, options);
            } else {
                dateString = date.toLocaleDateString(undefined, monthOptions);
            }

            // Create a time string.
            const hours = date.getHours();
            const minutes = date.getMinutes().toString().padStart(2, '0');

            let convItem = {
                "title": title,
                "conversationid": convo.id,
                "time": hours + ':' + minutes,
            };

            // Save entry under the date.
            if (!groupedByDate[dateString]) {
                groupedByDate[dateString] = [];
            }
            groupedByDate[dateString].push(convItem);
        }
    });

    // Convert the grouped objects into an array format that Mustache can iterate over.
    let convert = {
        groups: Object.keys(groupedByDate).map(key => ({
            key: key,
            objects: groupedByDate[key]
        }))
    };

    // Render history.
    const templateData = {
        "dates": convert.groups,
    };
    const {html, js} = await Templates.renderForPromise('block_gamibot/history', templateData);
    Templates.appendNodeContents('.block_gamibot_modal .block_gamibot-output', html, js);

    // Add a listener for the new dialog button.
    const btnNewDialog = document.getElementById('gamibot_history_new_dialog');
    btnNewDialog.addEventListener('mousedown', () => {
        newDialog();
    });
};

/**
 * Remove current chat from history.
 */
const removeFromHistory = () => {
    if (conversation.id !== 0 && allConversations.find(x => x.id === conversation.id) !== undefined) {
        // Build new allConversations array without deleted one.
        allConversations = allConversations.filter(obj => obj.id !== conversation.id);
    }
};

/**
 * Webservice Save conversation.
 * @param {*} question
 * @param {*} reply
 */
const saveConversationLocally = (question, reply) => {
    // Add to local representation.
    let message = {'purpose': purpose, 'message': question, 'sender': 'user'};
    conversation.messages.push(message);
    message = {'purpose': purpose, 'message': reply, 'sender': 'ai'};
    conversation.messages.push(message);
};

/**
 * Removes the last conversation and resets the UI
 */
const removeLastConversation = async () => {
    if (conversation && conversation.id && conversation.id !== 0) {
        await externalServices.deleteConversation(contextid, userid, conversation.id);
        removeFromHistory();
        conversation = {id: 0};
    }

    clearMessages();
};


/**
 * Clear output div.
 * @param {*} hideinput
 */
const clearMessages = (hideinput = false) => {
    const output = document.querySelector('.block_gamibot-output');
    if (output) {
        output.innerHTML = '';
    }
    // For showing history.
    let input = document.querySelector('.block_gamibot-input');
    if (input) {
        if (hideinput) {
            input.style.display = 'none';
        } else {
            input.style.display = 'flex';
        }
    }
};

const setModalHeader = (chat) => {
    const modalheader = document.querySelector('.block_gamibot_modal .modal-title div');
    if (modalheader !== null) {
        if (chat) {
            if (purpose === 'clarify') {
                modalheader.textContent = 'GamiBot - Dúvidas';
            } else if (purpose === 'summarize') {
                modalheader.textContent = 'GamiBot - Resumos';
            } else if (purpose === 'quiz') {
                modalheader.textContent = 'GamiBot - Quiz';
            }
        } else {
            modalheader.textContent = 'GamiBot';
        }
    }
    const modal = document.querySelector('.block_gamibot_modal');
    modal.classList.remove('onhistorypage');
};

/**
 * Attach event listener.
 * @param {*} textarea
 */
const addTextareaListener = (textarea) => {
    textarea.addEventListener('keydown', (event) => {
        // Handle submission.
        textareaOnKeydown(event);

        // Handle autgrow.
        // Reset the height to auto to get the correct scrollHeight.
        textarea.style.height = 'auto';

        // Fetch the computed styles.
        const computedStyles = window.getComputedStyle(textarea);
        const lineHeight = parseFloat(computedStyles.lineHeight);
        const paddingTop = parseFloat(computedStyles.paddingTop);
        const paddingBottom = parseFloat(computedStyles.paddingBottom);
        const borderTop = parseFloat(computedStyles.borderTopWidth);
        const borderBottom = parseFloat(computedStyles.borderBottomWidth);

        // Calculate the maximum height for four rows plus padding and borders.
        const maxHeight = (lineHeight * 4) + paddingTop + paddingBottom + borderTop + borderBottom;

        // Calculate the new height based on the scrollHeight.
        const newHeight = Math.min(textarea.scrollHeight + borderTop + borderBottom, maxHeight);

        // Set the new height.
        textarea.style.height = newHeight + 'px';
    });
};

/**
 * Action for textarea submission.
 * @param {*} event
 */
const textareaOnKeydown = (event) => {
    if (event.key === 'Enter' && !aiAtWork && !event.shiftKey) {
        aiAtWork = true;
        enterQuestion(event.target.value);
        event.preventDefault();
        event.target.value = '';
    }
};

/**
 * Submit form.
 */
const clickSubmitButton = () => {
    // Var aiAtWork to make it impossible to submit multiple questions at once.
    if (!aiAtWork) {
        aiAtWork = true;
        const textarea = document.getElementById('block_gamibot-input-id');
        enterQuestion(textarea.value);
        textarea.value = '';
    }
};

/**
 * Handle error from local_gamibot_manager.
 * @param {*} requestresult
 * @param {*} question
 * @param {*} contextid
 * @param {*} options
 * @returns {object}
 */
const errorHandling = async(requestresult, question, contextid, options) => {

    // If code 409, conversationid is already taken, try get new a one.
    if (requestresult.code == 409) {
        while (requestresult.code == 409) {
            try {
                let idresult = await externalServices.getNewConversationId(contextid);
                conversation.id = idresult.id;
                options.itemid = conversation.id;
            } catch (error) {
                displayException(error);
            }
            // Retry with new id.
            requestresult = await manager.askLocalGamibotManager(purpose, question, contextid, options);
            return requestresult;
        }
    }

    if (purpose === 'quiz') {
        if (QuizManager.status === 2) {
            QuizManager.feedback = 'Ocorreu um erro ao analisar.';
            setLoading(false);
        }

        // And write generic error message in chatbot.
        requestresult.result = await getString('error', 'block_gamibot');

        return requestresult;
    }

    // Change answer styling to differentiate from ai.
    const answerdivs = document.querySelectorAll('.awaitanswer');
    const answerdiv = answerdivs[answerdivs.length - 1];
    const messagediv = answerdiv.closest('.message');
    messagediv.classList.add('text-danger');

    // And write generic error message in chatbot.
    requestresult.result = await getString('error', 'block_gamibot');

    return requestresult;
};

/**
 * Check if modal should close on outside click.
 * @param {*} event
 */
const checkOutsideClick = (event) => {
    // View openfull acts like a normal modal.
    if (viewmode !== VIEW_OPENFULL) {
        event.preventDefault();
    }
};

/**
 * Set different viewmodes and save in local storage.
 * Also sets the icon and attaches toggle listener on first run.
 * @param {string} mode
 */
const setView = async(mode = '') => {
    const key = await hash('chatmode' + userid);
    // Check for saved viewmode.
    let savedmode = LocalStorage.get(key);
    if (mode == '') {
        if (!savedmode) {
            // Set default.
            mode = VIEW_CHATWINDOW;
        } else {
            mode = savedmode;
        }
    }
    // Save viewmode and set global var.
    LocalStorage.set(key, mode);
    viewmode = mode;

    const body = document.querySelector('body');
    // Remove both classes once before adding the current mode.
    body.classList.remove(VIEW_CHATWINDOW, VIEW_OPENFULL);
    body.classList.add(mode);

    const icon = document.getElementById('block_gamibot_viewicon');
    if (icon) {
        icon.classList.remove('fa-down-left-and-up-right-to-center', 'fa-up-right-and-down-left-from-center');
        if (viewmode === VIEW_CHATWINDOW) {
            icon.classList.add('fa-up-right-and-down-left-from-center');
        } else {
            icon.classList.add('fa-down-left-and-up-right-to-center');
        }
    }

    // Attach toggle listener if not already attached.
    const toggleButton = document.getElementById('block_gamibot_viewtoggle');
    if (toggleButton && !toggleButton._listenerAttached) {
        toggleButton.addEventListener('click', () => {
            setView(viewmode === VIEW_CHATWINDOW ? VIEW_OPENFULL : VIEW_CHATWINDOW);
        });
        toggleButton._listenerAttached = true;
    }

    const container = document.querySelector('.block_gamibot_modal .block_gamibot-dialog');
    if (container && container.classList.contains('onmenupage')) {
        await showMenu();
    }
};

/**
 * Is user allowed new queries.
 * @returns {message}
 */
const userAllowed = async() => {
    if (gamibotConfig.availability.available === 'disabled') {
        return gamibotConfig.availability.errormessage;
    }
    if (chatConfig.available === 'disabled') {
        return chatConfig.errormessage;
    }
    return '';
};

/**
 * Change to openfull view when screen is small.
 * @param {*} e
 */
const handleScreenWidthChange = (e) => {
    const body = document.querySelector('body');
    if (e.matches) {
        // Screen width is less than 576px
        body.classList.remove(VIEW_CHATWINDOW, VIEW_OPENFULL);
        body.classList.add(VIEW_OPENFULL);
    } else {
        body.classList.remove(VIEW_CHATWINDOW, VIEW_OPENFULL);
        body.classList.add(viewmode);
    }
};

/**
 * Show options modal.
 */
const showOptionsModal = () => {
    // Add a dynamic form to add options.
    // Always create the dynamic form modal, since it is being destroyed.
    optionsForm = new ModalForm({
        formClass: "block_gamibot\\form\\options_form",
        moduleName: "core/modal_save_cancel",
        args: {
            contextid: contextid,
        },
        modalConfig: {
            title: getString('options'),
        },
    });

    // Show modal.
    optionsForm.show();
};
