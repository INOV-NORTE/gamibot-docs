// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

import {call as fetchMany} from 'core/ajax';

/**
 * Get all converstations a User can see.
 * @param {int} userid
 * @param {int} contextid
 * @returns {mixed}
 */
export const getAllConversations = (
    userid,
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_all_conversations',
    args: {
        userid,
        contextid
}}])[0];

/**
 * Get all converstations a User can see.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getNewConversationId = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_new_conversation_id',
    args: {
        contextid,
}}])[0];

/**
 * Get all converstations a User can see.
 * @param {int} contextid
 * @param {int} userid
 * @param {int} conversationid
 * @returns {mixed}
 */
export const deleteConversation = (
    contextid,
    userid,
    conversationid,
) => fetchMany([{
    methodname: 'block_gamibot_delete_conversation',
    args: {
        contextid,
        userid,
        conversationid,
}}])[0];

/**
 * Get conversationcontext message limit.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getConversationcontextLimit = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_conversationcontext_limit',
    args: {
        contextid
    }
}])[0];

/**
 * Get all clarifications a User can see.
 * @param {int} userid
 * @param {int} contextid
 * @returns {mixed}
 */
export const getAllClarifications = (
    userid,
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_all_clarifications',
    args: {
        userid,
        contextid
    }}])[0];

/**
 * Get all clarifications a User can see.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getNewClarificationId = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_new_clarification_id',
    args: {
        contextid,
    }}])[0];

/**
 * Delete a clarification
 * @param {int} contextid
 * @param {int} userid
 * @param {int} clarificationid
 * @returns {mixed}
 */
export const deleteClarification = (
    contextid,
    userid,
    clarificationid,
) => fetchMany([{
    methodname: 'block_gamibot_delete_clarification',
    args: {
        contextid,
        userid,
        clarificationid,
    }}])[0];

/**
 * Get clarificationcontext message limit.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getClarificationcontextLimit = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_clarificationcontext_limit',
    args: {
        contextid
    }
}])[0];

/**
 * Get all summaries a User can see.
 * @param {int} userid
 * @param {int} contextid
 * @returns {mixed}
 */
export const getAllSummaries = (
    userid,
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_all_summaries',
    args: {
        userid,
        contextid
    }}])[0];

/**
 * Get all summaries a User can see.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getNewSummaryId = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_new_summary_id',
    args: {
        contextid,
    }}])[0];

/**
 * Delete a summary
 * @param {int} contextid
 * @param {int} userid
 * @param {int} summaryid
 * @returns {mixed}
 */
export const deleteSummary = (
    contextid,
    userid,
    summaryid,
) => fetchMany([{
    methodname: 'block_gamibot_delete_summary',
    args: {
        contextid,
        userid,
        summaryid,
    }}])[0];

/**
 * Get summarycontext message limit.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getSummarycontextLimit = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_summarycontext_limit',
    args: {
        contextid
    }
}])[0];

/**
 * Get all quizzes a User can see.
 * @param {int} userid
 * @param {int} contextid
 * @returns {mixed}
 */
export const getAllQuizzes = (
    userid,
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_all_quizzes',
    args: {
        userid,
        contextid
    }}])[0];

/**
 * Get all quizzes a User can see.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getNewQuizId = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_new_quiz_id',
    args: {
        contextid,
    }}])[0];

/**
 * Delete a quiz
 * @param {int} contextid
 * @param {int} userid
 * @param {int} quizid
 * @returns {mixed}
 */
export const deleteQuiz = (
    contextid,
    userid,
    quizid,
) => fetchMany([{
    methodname: 'block_gamibot_delete_quiz',
    args: {
        contextid,
        userid,
        quizid,
    }}])[0];

/**
 * Get quizcontext message limit.
 * @param {int} contextid
 * @returns {mixed}
 */
export const getQuizcontextLimit = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_get_quizcontext_limit',
    args: {
        contextid
    }
}])[0];


/**
 * Get current persona.
 * @param {int} contextid
 * @returns {mixed}
 */
export const reloadPersona = (
    contextid,
) => fetchMany([{
    methodname: 'block_gamibot_reload_persona',
    args: {
        contextid
    }
}])[0];
