// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

import {makeRequest} from 'local_gamibot_manager/make_request';
import {makeGetUserGamiStatsRequest} from 'local_gamibot_manager/get_user_gami_stats';
import {makeSubmitQuizScoreRequest} from 'local_gamibot_manager/submit_quiz_score';

/**
 * Get the async answer from the local_gamibot_manager.
 *
 * @param {string} purpose
 * @param {string} prompt
 * @param {number} contextid
 * @param {array} options
 * @returns {string}
 */
export const askLocalGamibotManager = async(purpose, prompt, contextid, options = []) => {
    let result = {};
    try {
        result = await makeRequest(purpose, prompt, 'block_gamibot', contextid, options);
    } catch (error) {
        result.code = 'aiconnector';
        result.result = error.error + " " + error.message;
        // For devs.
        result.result += error.backtrace;
    }
    return result;
};

/**
 * Get the async user stats from the local_gamibot_manager.
 *
 * @param {number} contextid
 * @param {array} options
 * @returns {object}
 */
export const getUserStats = async (contextid, options = []) => {
    let result = {};
    try {
        result = await makeGetUserGamiStatsRequest('block_gamibot', contextid, options);
    } catch (error) {
        result.code = 'aiconnector';
        result.result = error.error + " " + error.message;
        // For devs.
        result.result += error.backtrace;
        // eslint-disable-next-line no-console
        console.error(error);
    }
    return result;
};

/**
 * Submit a quiz score to the local_gamibot_manager.
 *
 * @param {number} points
 * @param {number} total
 * @param {number} topic
 * @param {number} contextid
 * @param {array} options
 * @returns {object}
 */
export const submitQuizScore = async (points, total, topic, contextid, options = []) => {
    let result = {};
    try {
        result = await makeSubmitQuizScoreRequest(points, total, topic, 'block_gamibot', contextid, options);
    } catch (error) {
        result.code = 'aiconnector';
        result.result = error.error + " " + error.message;
        // For devs.
        result.result += error.backtrace;
        // eslint-disable-next-line no-console
        console.error(error);
    }
    return result;
};
