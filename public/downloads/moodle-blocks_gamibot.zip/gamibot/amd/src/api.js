// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

const API_BASE_URL = 'http://localhost:3000';

const request = async(method, path, body = null) => {
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json'
        },
    };

    if (body) {
        options.body = JSON.stringify(body);
    }

    const response = await fetch(`${API_BASE_URL}${path}`, options);

    if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Error ${response.status}: ${errorText}`);
    }

    return await response.json();
};

// Subjects' routes
export const getAllSubjects = () => request('GET', '/subjects');
export const createSubject = ({name}) => request('POST', '/subjects', {name});
export const getSubjectById = (subjectId) => request('GET', `/subjects/${subjectId}`);
export const updateSubject = (subjectId, data) => request('PUT', `/subjects/${subjectId}`, data);
export const deleteSubject = (subjectId) => request('DELETE', `/subjects/${subjectId}`);
export const getUsersBySubject = (subjectId) => request('GET', `/subjects/${subjectId}/users`);

// Users' routes
export const createUser = (subjectId, {name, email}) => request('POST', `/subjects/${subjectId}/users`, {name, email});
export const getUserById = (subjectId, userId) => request('GET', `/subjects/${subjectId}/users/${userId}`);
export const updateUser = (subjectId, userId, data) => request('PUT', `/subjects/${subjectId}/users/${userId}`, data);
export const removeUserFromSubject = (subjectId, userId) => request('DELETE', `/subjects/${subjectId}/users/${userId}`);

// Stats' routes
export const getUserStats = (subjectId, userId) => request('GET', `/subjects/${subjectId}/users/${userId}/stats`);
// eslint-disable-next-line max-len
export const addUserConversation = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/conversations`);
export const addUserMinute = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/minutes`);
export const addUserQuiz = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/quizzes`);
// eslint-disable-next-line max-len
export const addUserFullyCorrectQuiz = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/fully-correct-quizzes`);
// eslint-disable-next-line max-len
export const addUserFailedQuiz = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/failed-quizzes`);
export const addUserDoubt = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/doubts`);
export const addUserSummaries = (subjectId, userId) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/summaries`);
// eslint-disable-next-line max-len
export const addUserPoints = (subjectId, userId, points) => request('POST', `/subjects/${subjectId}/users/${userId}/stats/points`, {points});

// Badges' routes
export const getUserBadges = (subjectId, userId) => request('GET', `/subjects/${subjectId}/users/${userId}/badges`);

// Topics' routes
export const createTopic = (subjectId, name) => request('POST', `/subjects/${subjectId}/topics`, {name});
export const getTopicsBySubject = (subjectId) => request('GET', `/subjects/${subjectId}/topics`);
export const getUserTopicProgress = (subjectId, userId) => request('GET', `/subjects/${subjectId}/users/${userId}/topics`);
// eslint-disable-next-line max-len
export const setUserTopicLevel = (subjectId, userId, topicId, level) => request('PUT', `/subjects/${subjectId}/users/${userId}/topics/${topicId}`, {level});
// eslint-disable-next-line max-len
export const getTopHighLevelTopics = (subjectId, userId) => request('GET', `/subjects/${subjectId}/users/${userId}/topics/top-high`);
export const getTopLowLevelTopics = (subjectId, userId) => request('GET', `/subjects/${subjectId}/users/${userId}/topics/top-low`);