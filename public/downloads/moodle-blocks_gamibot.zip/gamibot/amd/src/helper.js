// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

import {notifyFilterContentUpdated} from 'core_filters/events';
import {alert as moodleAlert} from 'core/notification';

let selectedVoice = null;
let currentAudioButton = null;

/**
 * Try to find a pt-PT voice first, then pt, then fallback
 */
export const selectPortugueseVoice = () => {
    const voices = window.speechSynthesis.getVoices();

    // 1. Try to find a specific European Portuguese voice (pt-PT)
    // Common names: "Joana" (macOS/iOS), "Helia" (Windows), "Google Português (Portugal)" (Android/Chrome)
    selectedVoice = voices.find(voice => voice.lang === 'pt-PT');

    // 2. Fallback: If no pt-PT is found, try any Portuguese
    if (!selectedVoice) {
        selectedVoice = voices.find(voice => voice.lang === 'pt');
    }

    // 3. Last resort: Use the default voice (usually English)
    if (!selectedVoice) {
        selectedVoice = voices.find(voice => voice.default);
    }

    // Debug: Check which voice was actually picked
    if (selectedVoice) {
        // eslint-disable-next-line no-console
        console.log(`Voice loaded: ${selectedVoice.name} (${selectedVoice.lang})`);
    }
};


/**
 * Focus textarea.
 */
export const focustextarea = () => {
    const textarea = document.getElementById('block_gamibot-input-id');
    if (textarea) {
        textarea.focus();
    }
};


/**
 * Scroll to bottom of modal body.
 */
export const scrollToBottom = () => {
    const modalContent = document.querySelector('.block_gamibot_modal .modal-body .block_gamibot-output-wrapper');
    if (modalContent) {
        modalContent.scrollTop = modalContent.scrollHeight;
    }
};


/**
 * Escape html.
 * @param {*} str
 */
export const escapeHTML = (str) => {
    if (str === null || str === undefined) {
        return '';
    }
    const escapeMap = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
        '`': '&#x60;',
        '/': '&#x2F;',
    };

    return String(str).replace(/[&<>"'`/]/g, function(match) {
        return escapeMap[match];
    });
};

/**
 * Hash function to get a hash of a string.
 *
 * @param {string} stringToHash the string to hash
 * @returns {Promise<string>} the promise containing a hex representation of the string encoded by SHA-256
 */
export const hash = async(stringToHash) => {
    const encoder = new TextEncoder();
    const data = encoder.encode(stringToHash);
    const hashAsArrayBuffer = await window.crypto.subtle.digest("SHA-256", data);
    const uint8ViewOfHash = new Uint8Array(hashAsArrayBuffer);
    return Array.from(uint8ViewOfHash)
        .map((b) => b.toString(16).padStart(2, "0"))
        .join("");
};

/**
 * Render mathjax formulas.
 *  @returns {void}
 */
export const renderMathjax = () => {
    // Render formulas using filter_mathjaxloader.
    if (typeof window.MathJax !== "undefined") {
        const content = document.querySelector('.block_gamibot_chat-output');
        if (content) {
            // Dispatch event to trigger rendering.
            notifyFilterContentUpdated(content);
        }
    }
};

/**
 * Reads text aloud using the browser's native synthesis.
 * @param {string} text - The text to read.
 * @param {Element} buttonElement - The audio button.
 */
export const speakText = (text, buttonElement) => {
    // Check browser support
    if (!('speechSynthesis' in window)) {
        // eslint-disable-next-line no-console
        console.error("Text-to-speech not supported in this browser.");
        return;
    }

    const parser = new DOMParser();
    const doc = parser.parseFromString(text, 'text/html');
    const cleanText = doc.body.textContent || "";

    // 1. If speaking, stop the current audio
    if (window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
        // If we clicked the SAME button, just stop (toggle off)
        if (currentAudioButton === buttonElement) {
            resetAudioButtonState(currentAudioButton);
            currentAudioButton = null;
            return;
        }
    }

    // 2. Reset the previous button immediately (if it exists)
    if (currentAudioButton) {
        resetAudioButtonState(currentAudioButton);
    }

    // 3. Create the new utterance
    const utterance = new SpeechSynthesisUtterance(cleanText);

    // Apply your Portuguese voice logic here (from previous step)
    if (selectedVoice) {
        utterance.voice = selectedVoice;
        utterance.lang = 'pt-PT';
    }

    // 4. Handle Events
    utterance.onstart = () => {
        currentAudioButton = buttonElement;
        setAudioButtonState(buttonElement, 'speaking');
    };

    utterance.onend = () => {
        resetAudioButtonState(buttonElement);
        if (currentAudioButton === buttonElement) {
            currentAudioButton = null;
        }
    };

    utterance.onerror = (event) => {
        // eslint-disable-next-line no-console
        console.error("Speech error:", event.error);
        resetAudioButtonState(buttonElement);
        currentAudioButton = null;
    };

    // 5. Speak
    window.speechSynthesis.speak(utterance);
};

/**
 * Set the state of the audio button.
 * @param {Element} btn The audio button
 * @param {string} state The state
 */
function setAudioButtonState(btn, state) {
    if (state === 'speaking') {
        btn.setAttribute('title', 'Parar reprodução');
        btn.setAttribute('aria-hidden', 'true');
        btn.innerHTML = '<i class="fa fa-stop"></i>';
    } else {
        resetAudioButtonState(btn);
    }
}


/**
 * Reset the state of the audio button.
 * @param {Element} btn The audio button
 */
function resetAudioButtonState(btn) {
    if (btn) {
        btn.setAttribute('title', 'Reproduzir mensagem de voz');
        btn.setAttribute('aria-hidden', 'true');
        btn.innerHTML = '<i class="fa fa-volume-up"></i>';
    }
}


/**
 * Display error alert.
 * @param {string} message
 * @param {string} title
 * @returns {Promise<void>}
 */
export const errorAlert = async(message, title = 'Erro no GamiBot') => {
    await moodleAlert(title, message, 'error');
};
