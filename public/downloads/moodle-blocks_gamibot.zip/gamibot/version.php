<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Version information for block_gamibot
 *
 * @package    block_gamibot
 * @copyright  2025 Centro de Inovação Pedagógica P. Porto
 * @author     Tobias Garske
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->release = '1.0';
$plugin->version = 2025062006;
$plugin->requires = 2024042200;
$plugin->component = 'block_gamibot';
$plugin->maturity = MATURITY_STABLE;
$plugin->dependencies = [
    'local_gamibot_manager' => 2025022100,
    // 'tiny_ai' => 2025022100,
];
