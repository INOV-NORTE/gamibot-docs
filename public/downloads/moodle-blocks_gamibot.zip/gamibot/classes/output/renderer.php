<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Renderer for content of block gamibot.
 *
 * @package    block_gamibot
 * @copyright  2024 Tobias Garske, ISB Bayern
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace block_gamibot\output;

use block_gamibot\local\helper;
use plugin_renderer_base;

/**
 * Rendering for block_gamibot
 */
class renderer extends plugin_renderer_base {
    /**
     * Defer to template.
     *
     * @param block_gamibot $block
     * @param int $courseid ID of the course
     * @param string $theme theme used for rendering
     * @return string html for the page
     */
    public function render_gamibot_content(\block_gamibot $block, int $courseid, string $theme = 'blue'): string {
        global $USER;

        // Get current personaprompt.
        //[$personaprompt, $personainfo] = \block_gamibot\local\persona::get_current_persona($block->context->id);

        $themeclassesmap = [
            'blue' => 'bg-base bg-secondary bg-terciary bg-quaternary',
            'green' => 'bg-base bg-secondary bg-terciary bg-quaternary',
            'purple' => 'bg-base bg-secondary bg-terciary bg-quaternary',
        ];

        $params = new \stdClass;
        $params->themeclasses = $themeclassesmap[$theme] ?? $themeclassesmap['blue'];
        $params->themeclass = 'theme-' . $theme;
        $params->title = get_string('gamibot', 'block_gamibot');
        $params->arialabel = get_string('gamibot:open', 'block_gamibot');
        $params->new = get_string('newdialog', 'block_gamibot');
        $params->history = get_string('history', 'block_gamibot');
        $params->persona = get_string('definepersona', 'block_gamibot');
        $params->newpersona = get_string('newpersona', 'block_gamibot');
        $params->usertemplates = get_string('usertemplates', 'block_gamibot');
        $params->systemtemplates = get_string('systemtemplates', 'block_gamibot');
        //$params->personaprompt = $personaprompt;
        //$params->personainfo = $personainfo;
        $params->showpersona = has_capability('block/gamibot:addinstance', $block->context, $USER->id);
        $params->showoptions = has_capability('block/gamibot:addinstance', $block->context, $USER->id);
        $params->personalink = get_config('block_gamibot', 'personalink');
        $params->showpersona = is_siteadmin() || (has_capability('block/gamibot:addinstance', $block->context, $USER->id)
            && $block->instance->parentcontextid != 1);
        $params->showoptions = is_siteadmin() || (has_capability('block/gamibot:addinstance', $block->context, $USER->id)
            && $block->instance->parentcontextid != 1);
        $params->userid = $USER->id;
        $params->courseid = $courseid;
        $params->contextid = $block->context->id;

        $params->isadmin = is_siteadmin();
        $params->badge = [
                'text' => get_string('private', 'block_gamibot'),
                'title' => get_string('badgeprivate', 'block_gamibot'),
        ];
        $this->page->requires->js_call_amd(
                'block_gamibot/dialog',
                'init',
                [$params]
        );

        return parent::render_from_template('block_gamibot/floatingbutton', $params);
    }
}
