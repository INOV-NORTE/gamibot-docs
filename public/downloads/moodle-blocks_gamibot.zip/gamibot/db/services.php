<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * External functions and service declaration for gamibot
 *
 * Documentation: {@link https://moodledev.io/docs/apis/subsystems/external/description}
 *
 * @package    block_gamibot
 * @category   webservice
 * @copyright  2024 Tobias Garske, ISB Bayern
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$functions = [
    'block_gamibot_get_all_conversations' => [
        'classname'     => 'block_gamibot\external\get_all_conversations',
        'methodname'    => 'execute',
        'description'   => 'Get all conversations.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_new_conversation_id' => [
        'classname'     => 'block_gamibot\external\get_new_conversation_id',
        'methodname'    => 'execute',
        'description'   => 'Save question and reply, get back the conversationid.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_delete_conversation' => [
        'classname'     => 'block_gamibot\external\delete_conversation',
        'methodname'    => 'execute',
        'description'   => 'Delete/Hide conversation from history.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_conversationcontext_limit' => [
        'classname'     => 'block_gamibot\external\get_conversationcontext_limit',
        'methodname'    => 'execute',
        'description'   => 'Get limit for messages to pass to query.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_all_clarifications' => [
        'classname'     => 'block_gamibot\external\get_all_clarifications',
        'methodname'    => 'execute',
        'description'   => 'Get all clarifications.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_new_clarification_id' => [
        'classname'     => 'block_gamibot\external\get_new_clarification_id',
        'methodname'    => 'execute',
        'description'   => 'Save request and clarification, get back the clarificationid.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_delete_clarification' => [
        'classname'     => 'block_gamibot\external\delete_clarification',
        'methodname'    => 'execute',
        'description'   => 'Delete/Hide clarification from history.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_clarificationcontext_limit' => [
        'classname'     => 'block_gamibot\external\get_clarificationcontext_limit',
        'methodname'    => 'execute',
        'description'   => 'Get limit for clarifications to pass to query.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_all_summaries' => [
        'classname'     => 'block_gamibot\external\get_all_summaries',
        'methodname'    => 'execute',
        'description'   => 'Get all summaries.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_new_summary_id' => [
        'classname'     => 'block_gamibot\external\get_new_summary_id',
        'methodname'    => 'execute',
        'description'   => 'Save request and summary, get back the summaryid.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_delete_summary' => [
        'classname'     => 'block_gamibot\external\delete_summary',
        'methodname'    => 'execute',
        'description'   => 'Delete/Hide summary from history.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_summarycontext_limit' => [
        'classname'     => 'block_gamibot\external\get_summarycontext_limit',
        'methodname'    => 'execute',
        'description'   => 'Get limit for summaries to pass to query.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_all_quizzes' => [
        'classname'     => 'block_gamibot\external\get_all_quizzes',
        'methodname'    => 'execute',
        'description'   => 'Get all quizzes.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_new_quiz_id' => [
        'classname'     => 'block_gamibot\external\get_new_quiz_id',
        'methodname'    => 'execute',
        'description'   => 'Save request and quiz, get back the quizid.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_delete_quiz' => [
        'classname'     => 'block_gamibot\external\delete_quiz',
        'methodname'    => 'execute',
        'description'   => 'Delete/Hide quiz from history.',
        'type'          => 'write',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_get_quizcontext_limit' => [
        'classname'     => 'block_gamibot\external\get_quizcontext_limit',
        'methodname'    => 'execute',
        'description'   => 'Get limit for quizzes to pass to query.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
    'block_gamibot_reload_persona' => [
        'classname'     => 'block_gamibot\external\reload_persona',
        'methodname'    => 'execute',
        'description'   => 'Reload persona.',
        'type'          => 'read',
        'ajax'          => true,
        'capabilities'  => 'local/gamibot_manager:use',
    ],
];
