<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

use local_gamibot_manager\gamibot_manager_utils;
use local_gamibot_manager\local\userinfo;

/**
 * Block class for block_gamibot
 *
 * @package    block_gamibot
 * @copyright  2024 ISB Bayern
 * @author     
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class block_gamibot extends block_base {

    /**
     * Initialize block
     *
     * @return void
     * @throws coding_exception
     */
    public function init(): void {
        $this->title = get_string('gamibot', 'block_gamibot');
    }

    /**
     * Allow the block to have a configuration page
     *
     * @return bool
     */
    #[\Override]
    public function has_config(): bool {
        return true;
    }

    /**
     * This function is called to output content before the footer.
     *
     * @param renderer_base $output The renderer instance used for outputting content.
     * @return void
     */
    public function before_footer(renderer_base $output): void {
        $theme = $this->config->theme ?? 'blue';

        var_dump($theme);

        $this->page->add_body_class('theme-' . $theme);
    }

    /**
     * Returns the block content. Content is cached for performance reasons.
     *
     * @return stdClass
     * @throws coding_exception
     * @throws moodle_exception
     */
    #[\Override]
    public function get_content(): stdClass {
        global $USER;

        if ($this->content !== null) {
            return $this->content;
        }

        $sitetheme = get_config('block_gamibot', 'theme');
        $theme = $this->config->theme ?? $sitetheme ?? 'blue';

        $themes = [
            'blue' => ['#FFFFFF', '#2563eb', '#1d4ed8', '#1e40af', '#1e40af40'],
            'green' => ['#FFFFFF', '#059669', '#047857', '#065f46', '#065f4640'],
            'purple' => ['#FFFFFF', '#6366f1', '#4f46e5', '#4338ca', '#4338ca40'],
        ];

        $colors = $themes[$theme] ?? $themes['blue'];

        $cssvars = ":root {
            --bg-base: {$colors[0]};
            --bg-secondary: {$colors[1]};
            --bg-terciary: {$colors[2]};
            --bg-quaternary: {$colors[3]};
            --muted: {$colors[4]};
        }";

        if (!$this->page->requires->is_head_done()) {
            $this->page->requires->css('/blocks/gamibot/styles.css');
        }
        $this->page->requires->js_init_code("document.head.insertAdjacentHTML('beforeend', `<style>$cssvars</style>`);");

        $this->content = new stdClass();
        $this->content->text = '';
        $this->content->footer = '';

        $context = \context_block::instance($this->instance->id);
        if (!has_capability('block/gamibot:view', $context)) {
            return $this->content;
        }

        // We retrieve the config for all the purposes we are using. This includes the purposes that tiny_ai uses, because even
        // if the chat purpose is not available, the user should still be able to use the chatbot for accessing the tiny_ai tools.
        $aiconfig = gamibot_manager_utils::get_ai_config($USER, $context->id, null,
            ['clarify', 'quiz', 'summarize']);
        if ($aiconfig['availability']['available'] === gamibot_manager_utils::AVAILABILITY_HIDDEN) {
            return $this->content;
        }
        $atleastonepurposenothidden =
            array_reduce($aiconfig['purposes'], fn($a, $b) => $a || $b['available'] !== gamibot_manager_utils::AVAILABILITY_HIDDEN,
                false);
        if (!$atleastonepurposenothidden) {
            return $this->content;
        }

        $this->content = new stdClass;

        /** @var block_gamibot\output\renderer $aioutput */
        $aioutput = $this->page->get_renderer('block_gamibot');
        $courseid = $this->page->course->id;
        $theme = $this->config->theme ?? 'blue';
        $this->content->text = $aioutput->render_gamibot_content($this, $courseid, $theme);

        if ($this->page->user_is_editing()) {
            return $this->content;
        }

        return $this->content;
    }

    /**
     * Returns false as there can be only one gamibot block on one page to avoid collisions.
     *
     * @return bool
     */
    #[\Override]
    public function instance_allow_multiple(): bool {
        return false;
    }

    /**
     * Returns on which page formats this block can be added.
     *
     * We do not want any user to create the block manually.
     * But me must add at least one applicable format here otherwise it will lead to an installation error,
     * because the block::_self_test fails.
     *
     * There are only two ways to create block instances:
     * - Check "add ai block" in the settings form of a course
     * - Admin has set up an automatic create of a block instance using the plugin settings.
     *
     * @return array
     */
    #[\Override]
    public function applicable_formats(): array {
        return array(
            'course-view' => true,  // Allow on standard course pages
            'site'        => false, // Disallow on Site Home (Front Page)
            'mod'         => false, // Disallow inside activities
            'my'          => false, // Disallow on Dashboard
            'all'         => false  // Disallow everywhere else by default
        );
    }

    /**
     * We don't want any user to manually create an instance of this block.
     *
     * @param $page
     * @return false
     */
    #[\Override]
    public function user_can_addto($page) {
        return false;
    }

    /**
     *  Do any additional initialization you may need at the time a new block instance is created
     *
     * @return boolean
     * /
     * @return true
     * @throws dml_exception
     */
    #[\Override]
    public function instance_create() {
        global $DB;

        // For standard dashboard keep the standard.
        /*if (isset($this->page->context) && $this->page->context::instance()->id != SYSCONTEXTID) {
            return true;
        }*/

        // For courses set default to show on all pages.
        if ($this->context->get_parent_context()->contextlevel === CONTEXT_COURSE) {
            $DB->update_record('block_instances', ['id' => $this->instance->id, 'pagetypepattern' => '*']);
        }
        return true;
    }

    /**
     * Allow block instance configuration.
     *
     * This function indicates that this block supports having a configuration
     * form accessible via the block settings UI.
     *
     * @return bool True if the block supports configuration, false otherwise.
     */
    public function instance_allow_config() {
        return true;
    }

    /**
     * Defines the configuration form for the block instance
     *
     * Adds form elements to the block configuration form
     *
     * @param MoodleQuickForm $mform the form to add elements to
     * @return void
     */
    public function instance_config_form($mform) {
        $mform->addElement('header', 'themeheader', get_string('select_theme', 'block_gamibot'));

        $mform->addElement('select', 'theme', get_string('theme_label', 'block_gamibot'), [
            'blue' => get_string('theme_blue', 'block_gamibot'),
            'green' => get_string('theme_green', 'block_gamibot'),
            'purple' => get_string('theme_purple', 'block_gamibot'),
        ]);
        $mform->setDefault('theme', 'blue');
    }
}
