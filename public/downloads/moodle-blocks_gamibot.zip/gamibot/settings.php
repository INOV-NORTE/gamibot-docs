<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Settings for the local_gamibot_manager plugin.
 *
 * @package    block_gamibot
 * @copyright  2024 ISB Bayern
 * @author     Tobias Garske
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die;

if ($hassiteconfig) {

    $ADMIN->add('blocksettings', new admin_category('block_gamibot_settings',
            new lang_string('pluginname', 'block_gamibot')));

    if ($ADMIN->fulltree) {

        $settings->add(new admin_setting_configtextarea('block_gamibot/showonpagetypes',
                new lang_string('showonpagetypes', 'block_gamibot'),
                new lang_string('showonpagetypesdesc', 'block_gamibot'),
                '',
        ));
        $settings->add(new admin_setting_configcheckbox('block_gamibot/replacehelp',
                new lang_string('replacehelp', 'block_gamibot'),
                '',
                0,
        ));
        $settings->add(new admin_setting_configselect(
            'block_gamibot/theme',
            new lang_string('theme_label', 'block_gamibot'),
            new lang_string('theme_desc', 'block_gamibot'),
            'blue',
            [
                'blue' => get_string('theme_blue', 'block_gamibot'),
                'green' => get_string('theme_green', 'block_gamibot'),
                'purple' => get_string('theme_purple', 'block_gamibot'),
            ]
        ));
    }
}
