# block_gamibot - Chat Frontend for local_gamibot_manager

This plugin provides a Frontend to converse with defined Ai´s from local_gamibot_manager.
Features are different viewmodes and a chat history.

# Settings

## Requirements

https://github.com/INOV-NORTE/moodle-local_gamibot_manager needs to be installed.

## Installing via uploaded ZIP file ##

1. Log in to your Moodle site as an admin and go to _Site administration >
   Plugins > Install plugins_.
2. Upload the ZIP file with the plugin code. You should only be prompted to add
   extra details if your plugin type is not automatically detected.
3. Check the plugin validation report and finish the installation.

## Installing manually ##

The plugin can be also installed by putting the contents of this directory to

    {your/moodle/dirroot}/blocks/gamibot

Afterwards, log in to your Moodle site as an admin and go to _Site administration >
Notifications_ to complete the installation.

Alternatively, you can run

    $ php admin/cli/upgrade.php

to complete the installation from the command line.
